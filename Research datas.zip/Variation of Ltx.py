import numpy as np
import matplotlib.pyplot as plt

Ls=1.15e-6
Cs=2.2e-6
Ceq=1.2e-6
#Lt= 3.26e-6
Lt= np.arange(1.2,12,0.5)*1e-6
Rt=0.5
Lr=Ls
Cr=Cs

#Rp= 0.2 # Ohm
#Rs= 0.2 # Ohm
#R0= 0.0005 #Ohm
R_load= 15 # Ohm
#Vs = 25 #Volts
mu_0 = 12.566*1e-7 # u0
r1 = 0.3 # m
r2 = 0.3 # m
n1 = 4 # nombre de tours du primaire
n2 = 4 # nombre de tours du secondaire
#d= 0.2 # distance de separation
#f= 1/(2*np.pi*np.sqrt((Lt-Ls)*Ceq))
f=1/(2*np.pi*np.sqrt(Ls*Cs)) # resonance
#f= np.arange(80,120,1)*1000
w=2*np.pi*f
#tension continue V_dc
Vdc= 24
# sortie du pont en H
alpha= 1 # decalage de phase entre les commandes des mosfets
Vin_eff= (((2*Vdc*np.sqrt(2))/np.pi)*np.cos(alpha/2))


##
d = 0.2 # distance entre l'emetteur et le recepteur 20 Cm
M  = (np.pi*mu_0*((r1*r2)**2)*(n1*n2)**0.5)/(2*d**3)

tt= 1j*w*Lr+1/(1j*Cr*w)
###
#Impedance reflechie
Z_sec = R_load + 1j * w * Lr + 1 / (1j * w * Cr) # impendance du secondaire

Zref = (w**2 * M**2) / Z_sec # Impedance reflechie d secondare vers le primaire

Zin=1j * w * Ls + 1 / (1j * w * Cs) + (1/((Rt + 1/(1j * w * Cs) + 1j * w * Lt + 1/(1j * w * Ceq) + Zref)*(w**2) * (Cs**2))) # Impedance d'entree du compensateur

# courant dans la bobiine emettrice
I_t=(Vin_eff / (1j * w * Cs)) / ((1j * w * Ls + 1 / (1j * w * Cs)) * (Rt + 1 / (1j * w * Cs) + 1j * w * Lt + 1 / (1j * w * Ceq) + Zref) + 1 / (w**2 * Cs**2))

# Courant dans l'emetteur
I_1= (Vin_eff * (Rt + 1 / (1j * w * Cs) + 1j * w * Lt + 1 / (1j * w * Ceq) + Zref)) / ((1j * w * Ls + 1 / (1j * w * Cs)) * (Rt + 1 / (1j * w * Cs) + 1j * w * Lt + 1 / (1j * w * Ceq) + Zref) + 1 / (w**2 * Cs**2))

# Courant dans le recepeteur
Ir=(M * Vin_eff) / (Cs * (R_load + 1j * w * Lr + 1 / (1j * w * Cr)) * ((1j * w * Ls + 1 / (1j * w * Cs)) * (Rt + 1 / (1j * w * Cs) + 1j * w * Lt + 1 / (1j * w * Ceq) + Zref) + 1 / (w**2 * Cs**2)))
#Ir= 1j*w*M*I_t/Z_sec

#phasz
im=np.imag(Zin)
re= np.real(Zin)
Phi= np.arctan(im/re)
Phi= np.degrees(Phi)
Phi

