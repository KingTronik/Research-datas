import numpy as np
import matplotlib.pyplot as plt
Ls=1.15e-6
#Ls= np.arange(0.8,3,0.1)*1e-6
Cs=2.2e-6
#f = 1/(2*np.pi*np.sqrt(Ls*Cs))
#f=100e3
#Ceq=1.2e-6
Ceq= np.arange(0.5,15,0.25)*1e-6
# define Lt as an array (commas are required in Python lists)
Lt = np.array([1.5, 2.1, 3.26, 4.2, 5.2]) * 1e-6
Z_sec= np.ndarray((len(Lt),len(Ceq)),dtype=np.complex64)
Zin= np.ndarray((len(Lt),len(Ceq)),dtype=np.complex64)
I_1= np.ndarray((len(Lt),len(Ceq)),dtype=np.complex64)
I_t= np.ndarray((len(Lt),len(Ceq)),dtype=np.complex64)
Ir= np.ndarray((len(Lt),len(Ceq)),dtype=np.complex64)
Z_ref= np.ndarray((len(Lt),len(Ceq)),dtype=np.complex64)
#Lt= np.arange(1.3,35,1)*1e-6
Rt=0.2
Lr=Ls
Cr=Cs
#Rp= 0.2 # Ohm
#Rs= 0.2 # Ohm
#R0= 0.0005 #Ohm
R_load= 15 # Ohm
#Vs = 25 #Volts
mu_0 = 12.566*1e-7 # u0
r1 = 0.3 # m
r2 = 0.3 # m
n1 = 4 # nombre de tours du primaire
n2 = 4 # nombre de tours du secondaire
#d= 0.2 # distance de separation
#f= 1/(2*np.pi*np.sqrt((Lt-Ls)*Ceq))
f=1/(2*np.pi*np.sqrt(Ls*Cs)) # resonance
#f= np.arange(80,120,1)*1000
w=2*np.pi*f
#tension continue V_dc
Vdc= 24
# sortie du pont en H
alpha= 1 # decalage de phase entre les commandes des mosfets
Vin_eff= (((2*Vdc*np.sqrt(2))/np.pi)*np.cos(alpha/2))

##
d = 0.2 # distance entre l'emetteur et le recepteur 20 Cm
M  = (np.pi*mu_0*((r1*r2)**2)*(n1*n2)**0.5)/(2*d**3)

# iterate with index and scalar L to avoid broadcasting shape errors
for idnx, L in enumerate(Lt):
    #Impedance reflechie (row will broadcast scalar across Ceq length)
    Z_sec[idnx, :] = R_load + 1j * w * Lr + 1 / (1j * w * Cr)  # impendance du secondaire

    # use row-wise operations: Z_ref becomes an array of length len(Ceq) for this L
    Z_ref[idnx, :] = (w**2 * M**2) / Z_sec[idnx, :]  # Impedance reflechie du secondaire vers le primaire

    # Use scalar L (not array Lt) and vector Ceq to compute row-wise values
    Zin[idnx, :] = 1j * w * Ls + 1 / (1j * w * Cs) + (
        1 / ((Rt + 1 / (1j * w * Cs) + 1j * w * L + 1 / (1j * w * Ceq) + Z_ref[idnx, :]) * (w**2) * (Cs**2))
    )  # Impedance d'entree du compensateur

    # courant dans la bobine emettrice (row-wise)
    I_t[idnx, :] = (Vin_eff / (1j * w * Cs)) / (
        (1j * w * Ls + 1 / (1j * w * Cs)) * (Rt + 1 / (1j * w * Cs) + 1j * w * L + 1 / (1j * w * Ceq) + Z_ref[idnx, :])
        + 1 / (w**2 * Cs**2)
    )

    # Courant dans l'emetteur (row-wise)
    I_1[idnx, :] = (Vin_eff * (Rt + 1 / (1j * w * Cs) + 1j * w * L + 1 / (1j * w * Ceq) + Z_ref[idnx, :])) / (
        (1j * w * Ls + 1 / (1j * w * Cs)) * (Rt + 1 / (1j * w * Cs) + 1j * w * L + 1 / (1j * w * Ceq) + Z_ref[idnx, :])
        + 1 / (w**2 * Cs**2)
    )

    # Courant dans le recepeteur (row-wise)
    Ir[idnx, :] = 1j * w * M * I_t[idnx, :] / Z_sec[idnx, :]


# afficher: plot each row (L) versus Ceq
for idx, L in enumerate(Lt):
    #plt.plot(Ceq, np.imag(Zin[idx, :]))
    plt.grid()
    plt.plot(Ceq, np.real(Zin[idx, :]), linestyle='--')
    plt.xlabel('Ceq (uF)')
    plt.legend([f'L={L*1e6:.2f}µH' for L in Lt])

for idx, L in enumerate(Lt):
    plt.plot(Ceq, np.imag(Zin[idx, :]))
    plt.grid()
    #plt.plot(Ceq, np.real(Zin[idx, :]), linestyle='--')
    plt.xlabel('Ceq (uF)')
    plt.legend([f'L={L*1e6:.2f}µH' for L in Lt])

for idx, L in enumerate(Lt):
# phasz
    im[idx,:] = np.imag(Zin[idx,:])
    re[idx,:] = np.real(Zin[idx,:] )
    Phi[idx,:] = np.arctan(im[idx,:] / re[idx,:])
    Phi[idx,:] = np.degrees(Phi[idx,:])
    plt.plot(Ceq,Phi[idx,:], label=f'L={L*1e6:.1f}µH')
    plt.legend()